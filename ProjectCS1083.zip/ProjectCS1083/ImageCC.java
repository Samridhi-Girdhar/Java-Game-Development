import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
/***************************************************************************
 * Project-CS1083 Game title: Wrapped & Loaded (images for round 2)
 *
 * @author (Samridhi Girdhar)
 * @version (28/03/2021)
 ************************************************************************** */
class ImageCC 
{
    private static final List<String> WEB_IMAGES = new ArrayList<>(List.of("Storm.png", "Storm1.png", "Storm2.png", "Storm3.png"));
    private static final List<String> OTHER_IMAGES = new ArrayList<>(List.of("Snowman.png", "Coins.png"));
    private static final int WEB_COUNT = 4;
    private static final int GHOST_COUNT = 1;
    private static final int COINS_COUNT = 1;
    private final List<String> availableImages = new ArrayList<>();
    private int webCounter = 0;
    private int ghostCounter = 0;
    private int coinsCounter = 0;

    public ImageCC() 
    {
        initializeImages();
    }

    private void initializeImages() 
    {
        // Add Web images
        availableImages.addAll(WEB_IMAGES);
        // Add Ghost and Coins images based on counts
        for (int i = 0; i < GHOST_COUNT; i++) {
            availableImages.add("Snowman.png");
        }
        for (int i = 0; i < COINS_COUNT; i++) {
            availableImages.add("Coins.png");
        }
        // Shuffle the list
        Collections.shuffle(availableImages);
    }

    public String getEmptySpaceImage() {
        // Shuffle the list if all images have been used
        if (availableImages.isEmpty()) {
            initializeImages();
        }
        // Get the next image from the list
        String image = availableImages.remove(0);
        // Update counters based on the image
        switch (image) {
            case "Storm.png":
            case "Storm1.png":
            case "Storm2.png":
            case "Storm3.png":
                webCounter++;
                break;
            case "Snowman.png":
                ghostCounter++;
                break;
            case "Coins.png":
                coinsCounter++;
                break;
        }
        return image;
    }

}
