import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.layout.Region;
import javafx.animation.PauseTransition;
import javafx.util.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
/***************************************************************************
 * Project-CS1083 Game title: Wrapped & Loaded (ROund 1)
 *
 * @author (Samridhi Girdhar)
 * @version (28/03/2021)
 ************************************************************************** */

 public class WrappedAndLoadedGame extends Application 
{
    private int vBucks = 0; // Initial V Bucks
    GridPane gridPane = createObjectsGrid();
    private final ImageSelector imageSelector = new ImageSelector();
    private Label vBucksLabel; // Declare vBucksLabel here
    private Label messageLabel;// Instantiate ImageSelector
    private int webImageCount = 0; 
    

    @Override
    public void start(Stage primaryStage) 
    {
        primaryStage.setTitle("Wrapped & Loaded");

        // Create top center label
        Label titleLabel = new Label("Wrapped & Loaded (Round 1)");
        titleLabel.setStyle("-fx-font-size: 40;");
        BorderPane.setAlignment(titleLabel, Pos.CENTER);

        VBox cardFlipGameBox = createCardFlipGame();
        BorderPane.setAlignment(cardFlipGameBox, Pos.CENTER_RIGHT);
        BorderPane.setMargin(cardFlipGameBox, new Insets(0, 20, 0, 0)); // Add some space to the right

        // Create an empty Region for the left position
        Region leftRegion = new Region();
        BorderPane.setMargin(leftRegion, new Insets(0, 40, 0, 0)); // Add some space to the left

        BorderPane.setAlignment(gridPane, Pos.CENTER);
        BorderPane.setMargin(gridPane, new Insets(20, 0, 0, 0)); // Add some space to the top

        // Create bottom HBox for labels
        HBox labelsBox = new HBox(10); // 10 is spacing between labels
        labelsBox.setAlignment(Pos.CENTER); // Align labels to center
        vBucksLabel = new Label("V-Bucks: " + vBucks);
        vBucksLabel.setStyle("-fx-font-size: 20;");
        messageLabel = new Label();
        messageLabel.setStyle("-fx-font-size: 20;");
        labelsBox.getChildren().addAll(vBucksLabel, messageLabel);

        // Create border pane and set components
        BorderPane borderPane = new BorderPane();
        borderPane.setTop(titleLabel);
        borderPane.setRight(cardFlipGameBox);
        borderPane.setCenter(gridPane);
        borderPane.setBottom(labelsBox); 
        borderPane.setLeft(leftRegion);
        borderPane.setRight(cardFlipGameBox);
        borderPane.setCenter(gridPane);

        borderPane.setPrefSize(800, 800); // Set preferred width and height

        // Set scene
        Scene scene = new Scene(borderPane);
        
        // Disable window resizing
        primaryStage.setResizable(false);

        // Set the scene to the stage
        primaryStage.setScene(scene);

        // Show the stage
        primaryStage.show();
    }

    // Method to create the card flip game
    private VBox createCardFlipGame() 
    {
        VBox cardFlipGameBox = new VBox();
        cardFlipGameBox.setAlignment(Pos.CENTER);
        cardFlipGameBox.setSpacing(20);

        // Array to hold paths of front images for 6 cards
        String[] frontImages = {
                "RedCard.png", "YellowCard.png", "BlueCard.png",
                "GreenCard.png", "OrangeCard.png", "WhiteCard.png"
        };

        // Shuffle the front images array
        shuffleArray(frontImages);

        for (int i = 0; i < 6; i++) {
            ImageView imageView = new ImageView();
            imageView.setFitWidth(120);
            imageView.setFitHeight(110);
            imageView.setRotate(180);
            imageView.setImage(new Image("Back.png")); // Set the image to show on the back of the card
            final int finalI = i; // Declare local variable i as final
            imageView.setOnMouseClicked(event -> flipCard(imageView, frontImages[finalI]));
            cardFlipGameBox.getChildren().add(imageView);
        }

        return cardFlipGameBox;
    }

    // Method to shuffle the array
    private void shuffleArray(String[] array) {
        Random rnd = new Random();
        for (int i = array.length - 1; i > 0; i--) {
            int index = rnd.nextInt(i + 1);
            // Swap elements at index i and index
            String temp = array[index];
            array[index] = array[i];
            array[i] = temp;
        }
    }

    // Method to flip the card
    private void flipCard(ImageView imageView, String frontImagePath) 
    {
        // Create a timeline for the animation
        Timeline timeline = new Timeline();
        // Define the keyframe for the animation
        KeyValue keyValue = new KeyValue(imageView.rotateProperty(), 0); // Rotate back to 0 degrees
        KeyFrame keyFrame = new KeyFrame(Duration.seconds(1), keyValue);
        timeline.getKeyFrames().add(keyFrame);
        // Play the animation
        timeline.play();

        // Set the image to show on the front of the card after the animation completes
        timeline.setOnFinished(event -> 
        {
            imageView.setImage(new Image(frontImagePath));
            // If the card is flipped to the front, reveal the associated box
            revealBoxForCard(frontImagePath);
        });
    }

    // Method to create the grid of objects
    private GridPane createObjectsGrid() 
    {
        GridPane gridPane = new GridPane();
        gridPane.setHgap(50);
        gridPane.setVgap(50);

        for (int i = 1; i <= 6; i++) {
            ImageView boxImageView = new ImageView(new Image(getBoxImage(i)));
            boxImageView.setFitWidth(200);
            boxImageView.setFitHeight(200);
            gridPane.add(boxImageView, (i - 1) % 2, (i - 1) / 2);
        }

        return gridPane;
    }

    // Method to get the box image path
    private String getBoxImage(int index) 
    {
        switch (index) {
            case 1:
                return "RedBox.png";
            case 2:
                return "YellowBox.png";
            case 3:
                return "BlueBox.png";
            case 4:
                return "GreenBox.png";
            case 5:
                return "OrangeBox.png";
            case 6:
                return "WhiteBox.png";
            default:
                return "";
        }
    }



    private void revealBoxForCard(String cardImagePath) 
    {
    String color = getColorFromImagePath(cardImagePath);
    String boxImagePath = getBoxImageByColor(color);
    // Find the associated box image view and remove it
    for (int i = 0; i < gridPane.getChildren().size(); i++) 
    {
        ImageView imageView = (ImageView) gridPane.getChildren().get(i);
        if (imageView.getImage() != null && imageView.getImage().getUrl().endsWith(boxImagePath)) 
        {
            imageView.setImage(null); // Remove the box image
            // Show empty space image
            // Update vBucks if Coins image is shown
            String emptySpaceImagePath = imageSelector.getEmptySpaceImage(); // Use ImageSelector here
            imageView.setImage(new Image(emptySpaceImagePath));

            // Update vBucks if Coins image is shown
            if (emptySpaceImagePath.equals("Coins.png")) {
                vBucks += 1000;
                vBucksLabel.setText("V-Bucks: " + vBucks); // Update vBucksLabel text
                messageLabel.setText("Congrats! You won"); // Set message for Coins
                // Freeze the program after showing the image
                PauseTransition pause = new PauseTransition(Duration.seconds(1));
                pause.setOnFinished(event -> {
                    // Launch the second class after the pause
                    WrappedAndLoadedGame2 ccGame = new WrappedAndLoadedGame2();
                    Stage stage = new Stage();
                    ccGame.start(stage);
                    // Close the current stage
                    ((Stage) gridPane.getScene().getWindow()).close();
                });
                pause.play();
            } else if (emptySpaceImagePath.equals("Ghost.png")) {
                messageLabel.setText("Oops! Try again"); // Set message for Ghost
                // Freeze the program after showing the image
                PauseTransition pause = new PauseTransition(Duration.seconds(1));
                pause.setOnFinished(event -> {
                    // Launch the second class after the pause
                    WrappedAndLoadedGame2 ccGame = new WrappedAndLoadedGame2();
                    Stage stage = new Stage();
                    ccGame.start(stage);
                    // Close the current stage
                    ((Stage) gridPane.getScene().getWindow()).close();
                });
                pause.play();
            }

            break;
        }
    }
    }

    // Method to get the color from the card image path
    private String getColorFromImagePath(String imagePath) 
    {
        // Assuming the color is the first part of the image file name before "Card.png"
        String[] parts = imagePath.split("/");
        String fileName = parts[parts.length - 1];
        String color = fileName.substring(0, fileName.indexOf("Card"));
        return color;
    }

    // Method to get the box image path by color
    private String getBoxImageByColor(String color) 
    {
        switch (color.toLowerCase()) {
            case "red":
                return "RedBox.png";
            case "yellow":
                return "YellowBox.png";
            case "blue":
                return "BlueBox.png";
            case "green":
                return "GreenBox.png";
            case "orange":
                return "OrangeBox.png";
            case "white":
                return "WhiteBox.png";
            default:
                return "";
        }
    }
    
}
